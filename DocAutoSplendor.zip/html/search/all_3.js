var searchData=
[
  ['getcountplayer',['GetCountPlayer',['../class_splendor_1_1_connection_d_b.html#ac3da13ea7bbb9b6e5b7eb5b7e70cbf2f',1,'Splendor.ConnectionDB.GetCountPlayer()'],['../class_splendor_1_1_connection_d_b.html#ac3da13ea7bbb9b6e5b7eb5b7e70cbf2f',1,'Splendor.ConnectionDB.GetCountPlayer()']]],
  ['getlistcardaccordingtolevel',['GetListCardAccordingToLevel',['../class_splendor_1_1_connection_d_b.html#abcd995d0fa97aa5f3a40ff5c23b22502',1,'Splendor.ConnectionDB.GetListCardAccordingToLevel(int level)'],['../class_splendor_1_1_connection_d_b.html#abcd995d0fa97aa5f3a40ff5c23b22502',1,'Splendor.ConnectionDB.GetListCardAccordingToLevel(int level)']]],
  ['getplayername',['GetPlayerName',['../class_splendor_1_1_connection_d_b.html#a7d715d5452049ad06f4a407fa5df151c',1,'Splendor.ConnectionDB.GetPlayerName(int id)'],['../class_splendor_1_1_connection_d_b.html#a7d715d5452049ad06f4a407fa5df151c',1,'Splendor.ConnectionDB.GetPlayerName(int id)']]]
];
