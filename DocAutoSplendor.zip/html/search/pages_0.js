var searchData=
[
  ['splendorgame',['SplendorGame',['../md__r_e_a_d_m_e.html',1,'']]],
  ['splendor',['Splendor',['../md__splendor-master__splendor-master__r_e_a_d_m_e.html',1,'']]]
];
