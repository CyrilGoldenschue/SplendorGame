var searchData=
[
  ['player',['Player',['../class_splendor_1_1_player.html',1,'Splendor']]],
  ['prestigept',['PrestigePt',['../class_splendor_1_1_card.html#ab094721affd92c2e08ef94fde69b11e6',1,'Splendor::Card']]]
];
