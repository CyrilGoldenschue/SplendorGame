var searchData=
[
  ['insertnewplayer',['InsertNewPlayer',['../class_splendor_1_1_connection_d_b.html#a1d13f004dc4c4ec8f9a3cc6caf24b7fc',1,'Splendor.ConnectionDB.InsertNewPlayer(string namePlayer, int idPlayer)'],['../class_splendor_1_1_connection_d_b.html#a1d13f004dc4c4ec8f9a3cc6caf24b7fc',1,'Splendor.ConnectionDB.InsertNewPlayer(string namePlayer, int idPlayer)']]]
];
