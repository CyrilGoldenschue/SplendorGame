var searchData=
[
  ['verifyplayer',['VerifyPlayer',['../class_splendor_1_1_connection_d_b.html#ad35be5ce4c52262a37f32f5c8872a927',1,'Splendor::ConnectionDB']]]
];
