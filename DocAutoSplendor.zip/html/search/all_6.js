var searchData=
[
  ['name',['Name',['../class_splendor_1_1_player.html#ae3952a0b3231cb4f3e7840f6a5d7dbd3',1,'Splendor::Player']]]
];
