var searchData=
[
  ['form2',['Form2',['../class_splendor_1_1_form2.html',1,'Splendor']]],
  ['formaddplayer',['FormAddPlayer',['../class_splendor_1_1_form_add_player.html',1,'Splendor.FormAddPlayer'],['../class_splendor_1_1_form_add_player.html#a358cdc1d1043c77821fc5b4ad2de41fa',1,'Splendor.FormAddPlayer.FormAddPlayer()']]],
  ['frmsplendor',['frmSplendor',['../class_splendor_1_1frm_splendor.html',1,'Splendor.frmSplendor'],['../class_splendor_1_1frm_splendor.html#ad9c938893d23192acb1996053e3ea87b',1,'Splendor.frmSplendor.frmSplendor()'],['../class_splendor_1_1frm_splendor.html#ad9c938893d23192acb1996053e3ea87b',1,'Splendor.frmSplendor.frmSplendor()']]],
  ['frmsplendor_5fload',['frmSplendor_Load',['../class_splendor_1_1frm_splendor.html#a38b0181bf94f24ac5bf703e05485b3ae',1,'Splendor::frmSplendor']]]
];
