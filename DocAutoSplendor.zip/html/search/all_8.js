var searchData=
[
  ['ress',['Ress',['../class_splendor_1_1_card.html#ac39a4541ce990d6ae51c172df84bba4d',1,'Splendor::Card']]],
  ['ressources',['Ressources',['../class_splendor_1_1_player.html#a1c5ccd2470e3bbc84e9a156bc323bfd0',1,'Splendor.Player.Ressources()'],['../namespace_splendor.html#abc955fe800ad5f701f777df0a2a29dc2',1,'Splendor.Ressources()']]]
];
