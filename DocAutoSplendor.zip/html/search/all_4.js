var searchData=
[
  ['id',['Id',['../class_splendor_1_1_player.html#ada5c2effb2ecf76e91a09b44a326b801',1,'Splendor::Player']]],
  ['insertnewplayer',['InsertNewPlayer',['../class_splendor_1_1_connection_d_b.html#a1d13f004dc4c4ec8f9a3cc6caf24b7fc',1,'Splendor.ConnectionDB.InsertNewPlayer(string namePlayer, int idPlayer)'],['../class_splendor_1_1_connection_d_b.html#a1d13f004dc4c4ec8f9a3cc6caf24b7fc',1,'Splendor.ConnectionDB.InsertNewPlayer(string namePlayer, int idPlayer)']]]
];
