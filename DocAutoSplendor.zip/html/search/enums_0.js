var searchData=
[
  ['ressources',['Ressources',['../namespace_splendor.html#abc955fe800ad5f701f777df0a2a29dc2',1,'Splendor']]]
];
