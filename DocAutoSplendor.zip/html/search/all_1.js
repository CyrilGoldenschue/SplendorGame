var searchData=
[
  ['deleteplayer',['DeletePlayer',['../class_splendor_1_1_connection_d_b.html#a5f5811a77013e4fc445bcd80dacaee5e',1,'Splendor::ConnectionDB']]],
  ['dispose',['Dispose',['../class_splendor_1_1frm_splendor.html#a749f4f1d67c78e74aa1a55aa6fdd754b',1,'Splendor.frmSplendor.Dispose()'],['../class_splendor_1_1_form2.html#ae25c3bea33600b90d8cc4f421fa18702',1,'Splendor.Form2.Dispose()'],['../class_splendor_1_1frm_splendor.html#a749f4f1d67c78e74aa1a55aa6fdd754b',1,'Splendor.frmSplendor.Dispose()'],['../class_splendor_1_1_form_add_player.html#a13cb025e489ac0da89ac01aa049ca515',1,'Splendor.FormAddPlayer.Dispose()']]]
];
