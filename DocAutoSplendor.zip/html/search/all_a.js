var searchData=
[
  ['tostring',['ToString',['../class_splendor_1_1_card.html#a3403c28ee02b119ee5aae5bd10eee468',1,'Splendor.Card.ToString()'],['../class_splendor_1_1_card.html#a3403c28ee02b119ee5aae5bd10eee468',1,'Splendor.Card.ToString()']]]
];
