var searchData=
[
  ['id',['Id',['../class_splendor_1_1_player.html#ada5c2effb2ecf76e91a09b44a326b801',1,'Splendor::Player']]]
];
