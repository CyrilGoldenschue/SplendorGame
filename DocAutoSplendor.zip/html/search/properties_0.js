var searchData=
[
  ['coins',['Coins',['../class_splendor_1_1_player.html#a729fa09f28e378e7934f3ae54ea463e9',1,'Splendor::Player']]],
  ['cout',['Cout',['../class_splendor_1_1_card.html#af3c65d4d543f453d5c481682233745c7',1,'Splendor::Card']]]
];
