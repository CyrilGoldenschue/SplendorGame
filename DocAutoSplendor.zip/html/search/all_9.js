var searchData=
[
  ['splendorgame',['SplendorGame',['../md__r_e_a_d_m_e.html',1,'']]],
  ['splendor',['Splendor',['../md__splendor-master__splendor-master__r_e_a_d_m_e.html',1,'']]],
  ['properties',['Properties',['../namespace_splendor_1_1_properties.html',1,'Splendor']]],
  ['splendor',['Splendor',['../namespace_splendor.html',1,'']]]
];
