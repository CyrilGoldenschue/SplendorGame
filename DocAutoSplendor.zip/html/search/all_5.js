var searchData=
[
  ['level',['Level',['../class_splendor_1_1_card.html#a814a3f18218c61238eb594402bbef7fa',1,'Splendor::Card']]]
];
