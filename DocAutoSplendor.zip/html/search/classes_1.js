var searchData=
[
  ['form2',['Form2',['../class_splendor_1_1_form2.html',1,'Splendor']]],
  ['formaddplayer',['FormAddPlayer',['../class_splendor_1_1_form_add_player.html',1,'Splendor']]],
  ['frmsplendor',['frmSplendor',['../class_splendor_1_1frm_splendor.html',1,'Splendor']]]
];
